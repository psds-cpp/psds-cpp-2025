#include <cstring>
#include <string>

class CowString {

};
